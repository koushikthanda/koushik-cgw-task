import { LightningElement, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import createInvoiceAndLineItems from '@salesforce/apex/InvoiceController.createInvoiceAndLineItems';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class InvoiceDataTable extends LightningElement {
    urlParams = {};
    urlParamsList = [];

    @wire(CurrentPageReference)
    getCurrentPageReference(pageRef) {
        console.log('getCurrentPageReference is called ')
        if (pageRef) {
            const state = pageRef.state || {};

          
        console.log('State from URL: ', state);
            this.urlParams = {
                origin_record: state.c__origin_record,
                account: state.c__account,
                invoice_date: state.c__invoice_date,
                invoice_due_date: state.c__invoice_due_date,
                child_relationship_name: state.c__child_relationship_name,
                line_item_description: state.c__line_item_description,
                line_item_quantity: state.c__line_item_quantity,
                line_item_unit_price: state.c__line_item_unit_price,
            };

           
            this.urlParamsList = Object.keys(this.urlParams).map((key) => ({
                key: key,
                value: this.urlParams[key],
            }));

            console.log('this.urlParamsList = ', JSON.stringify(this.urlParamsList.value));
           this.printUrlParamsList();
            
        }
    }
    
    printUrlParamsList() {
        console.log('Printing URL Params List:');
        this.urlParamsList.forEach(param => {
            console.log(`${param.key}: ${param.value}`);
        });
    }
    

    handleCreateInvoice() {
        const inputData = {
            accountId: this.urlParams.account,
            invoiceDate: this.urlParams.invoice_date,
            dueDate: this.urlParams.invoice_due_date,
        };

        createInvoiceAndLineItems({ inputData })
            .then((invoiceId) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: `Invoice created successfully! Invoice ID: ${invoiceId}`,
                        variant: 'success',
                    })
                );
                console.log('*invoice is created');
            })
            .catch((error) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: `Error creating invoice: ${error.body.message}`,
                        variant: 'error',
                    })
                );
            });
    }
}
